#include <ESP32Servo.h>

Servo myServo;

const int servoPin = 5;
const int greenLED = 27;
const int yellowLED = 14;

void setup() {
  myServo.attach(servoPin);

  pinMode(greenLED, OUTPUT);
  pinMode(yellowLED, OUTPUT);
}

void loop() {

  // OPEN
  myServo.write(90);
  digitalWrite(greenLED, HIGH);
  digitalWrite(yellowLED, LOW);
  delay(2000);

  // CLOSE
  myServo.write(0);
  digitalWrite(greenLED, LOW);
  digitalWrite(yellowLED, HIGH);
  delay(2000);
}
